package at.spengergasse.schwarzer_johann;

public class Dealer extends Player {
}